﻿/*
 * Jordan Ross
 * March 8 2019
 * While Example
 * Label
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184517whileExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            /*Make sure you add a text file to your project
             * Set and Build Action property to Content
             * and the Copy to Output Ditrectory to Copy Always
             */
            System.IO.StreamReader reader = new System.IO.StreamReader("myFile.txt");
            try {
                string output = "";
                while (!reader.EndOfStream)
                    {
                    output +=  reader.ReadLine()+Environment.NewLine;

                }
                lblOutput.Content = output;
            } catch(Exception ex) {  }
        }
    }
}
